// 選んだ飾りの画像の操作パネル(初期画面の下、ナビバーの場所に重ねて出す。画像を選んでいる間だけ)。
//  濃さ(スライダー)・左右反転・奥/手前・いちばん上へ・複製・削除(2 回押し)・選択の解除
import QtQuick
import OpenCruise

Panel {
    id: root
    property Item store: null
    readonly property string sid: store ? store.selectedId : ""
    readonly property real unit: Theme.uiScale
    readonly property bool compact: width < 1100 * unit

    radius: Theme.radius + 6
    tint: Theme.accent
    tintAmount: 0.05
    border.color: Theme.mix(Theme.panelBorder, Theme.accent, 0.5)

    property bool confirmDelete: false
    property real confirmAt: 0
    onSidChanged: confirmDelete = false
    Timer { id: confirmTimer; interval: 3000; onTriggered: root.confirmDelete = false }

    // ListModel の値は束縛で追えないことがあるので、操作のたびに読み直す
    property int tick: 0
    function cur(key, d) { tick; const it = store ? store.get(sid) : null; return it ? it[key] : d }
    function setv(key, v, save) { store.setValue(sid, key, v, save); tick++ }

    component PanelButton: Rectangle {
        id: b
        property string icon: ""
        property string text: ""
        property bool on: false
        property string tone: "normal"   // "normal" / "danger" / "dangerSolid"
        signal clicked()
        readonly property color toneColor: tone === "normal" ? Theme.accent : Theme.error
        height: Math.round(52 * root.unit)
        width: Math.max(height, bRow.implicitWidth + 26 * root.unit)
        radius: height / 2
        color: tone === "dangerSolid" ? Theme.mix(Theme.error, "#000000", bMouse.pressed ? 0.2 : 0)
             : on ? Theme.mix(Theme.accentFill, "#000000", bMouse.pressed ? 0.2 : 0)
             : Theme.mix(Theme.panel, toneColor, bMouse.pressed ? 0.35 : 0.08)
        border.width: (on || tone === "dangerSolid") ? 0 : 1.5
        border.color: tone === "normal" ? Theme.panelBorder : toneColor
        anchors.verticalCenter: parent ? parent.verticalCenter : undefined
        Row {
            id: bRow
            anchors.centerIn: parent
            spacing: 6 * root.unit
            MaterialIcon {
                anchors.verticalCenter: parent.verticalCenter
                name: b.icon
                size: Math.round(b.height * 0.5)
                color: b.tone === "dangerSolid" ? "#ffffff" : b.on ? Theme.textOnAccent : b.toneColor
            }
            Text {
                visible: b.text !== ""
                anchors.verticalCenter: parent.verticalCenter
                font.family: Theme.fontFamily
                font.pixelSize: Math.round(b.height * 0.36)
                font.bold: true
                color: b.tone === "dangerSolid" ? "#ffffff" : b.on ? Theme.textOnAccent : Theme.textPrimary
                text: b.text
            }
        }
        MouseArea { id: bMouse; anchors.fill: parent; onClicked: b.clicked() }
    }

    Row {
        id: row
        anchors { left: parent.left; leftMargin: 16 * root.unit; verticalCenter: parent.verticalCenter }
        spacing: 10 * root.unit

        // 濃さ
        SettingsSlider {
            anchors.verticalCenter: parent.verticalCenter
            width: Math.max(260 * root.unit, root.width - buttons.width - 60 * root.unit)
            height: Math.round(56 * root.unit)
            from: 5
            iconName: "opacity"
            iconMinName: "opacity"
            value: Math.round(root.cur("op", 1) * 100)
            onMoved: (v) => root.setv("op", v / 100, false)
            onReleased: root.store.save()
        }

        Row {
            id: buttons
            anchors.verticalCenter: parent.verticalCenter
            spacing: 8 * root.unit
            PanelButton {
                icon: "flip"
                text: root.compact ? "" : "反転"
                on: root.cur("flip", false)
                onClicked: root.setv("flip", !root.cur("flip", false), true)
            }
            // 奥 / 手前(ウィジェットより後ろか前か)
            PanelButton {
                icon: "flip_to_back"
                text: root.compact ? "" : "奥"
                on: !root.cur("front", false)
                onClicked: root.setv("front", false, true)
            }
            PanelButton {
                icon: "flip_to_front"
                text: root.compact ? "" : "手前"
                on: root.cur("front", false)
                onClicked: root.setv("front", true, true)
            }
            PanelButton {
                icon: "vertical_align_top"
                text: root.compact ? "" : "いちばん上へ"
                onClicked: { root.store.raise(root.sid); root.tick++ }
            }
            PanelButton {
                icon: "content_copy"
                text: root.compact ? "" : "複製"
                onClicked: root.store.duplicate(root.sid)
            }
            PanelButton {
                icon: "delete"
                tone: root.confirmDelete ? "dangerSolid" : "danger"
                text: root.confirmDelete ? "もう一度押すと削除" : (root.compact ? "" : "削除")
                onClicked: {
                    if (!root.confirmDelete) {
                        root.confirmDelete = true
                        root.confirmAt = Date.now()
                        confirmTimer.restart()
                        return
                    }
                    if (Date.now() - root.confirmAt < 400) return   // 2 度押しの勢いで消さない
                    confirmTimer.stop()
                    root.confirmDelete = false
                    root.store.remove(root.sid)
                }
            }
            PanelButton {
                icon: "close"
                onClicked: root.store.selectedId = ""
            }
        }
    }
}
