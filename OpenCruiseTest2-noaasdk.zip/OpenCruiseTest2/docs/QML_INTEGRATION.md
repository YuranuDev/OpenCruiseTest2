# QML の移植メモ（Windows で確認した UI を実際の QML 側へ移す）

このプロジェクトの `app/qml/` は、外部とは「コンテキストプロパティ 5 つ」と「C++ 型 1 つ」でしか繋がっていない。
移植先の QML プロジェクトに、下記の窓口を用意すれば QML ファイルはそのまま持っていける。

## 1. QML が前提にしているもの

### コンテキストプロパティ（`main.cpp` で `setContextProperty` している）

| 名前 | 型 | 使われ方 |
|---|---|---|
| `clock` | `ClockModel` | `timeText`, `dateText` |
| `can` | `DummyCanModel` | `speedKmh`, `rpm`, `coolantTempC`, `fuelPercent`, `sourceText` |
| `androidAuto` | `AndroidAutoController` | 下表 |
| `startFullscreen` | bool | `Main.qml` のみ（開発用。移植先では不要） |
| `startOnSettings` | bool | `Main.qml` のみ（開発用。移植先では不要） |

`androidAuto` から QML が読むもの:

| 種別 | 名前 | 用途 |
|---|---|---|
| property | `stateKey` | `"unavailable"/"waiting"/"connecting"/"connected"/"streaming"`（色分け・表示切替） |
| property | `stateText`, `detailText` | 状態の日本語表示 |
| property | `sourceText`, `lastIssue` | 設定画面の診断表示 |
| property | `attemptCount`, `videoPacketCount`, `frameCount`, `videoInfo` | 待機中案内・設定画面の統計 |
| method | `attachSurface(surface)` | `HomeScreen.qml` が `VideoSurfaceItem` を渡す（唯一の呼び出し） |

### C++ 型

- `VideoSurfaceItem`（`QQuickPaintedItem`、`import OpenCruise`）。映像を描く領域。
  `submitFrame(QImage)` を C++ から呼ぶと表示される。QML からは `Q_INVOKABLE clear()` と `hasFrame` だけ。
- `Theme`（シングルトン QML。`Theme.qml` は `QT_QML_SINGLETON_TYPE` を付けて登録している）。
  移植先で既存のテーマがあるなら、`Theme.xxx` の参照を置換するか、`Theme.qml` の値だけ合わせる。

## 2. 移植の手順（おすすめ順）

1. **QML だけ先に移す**: `ActionButton / ConnectionBadge / CanPanel / HomeScreen / SettingsScreen` と `Theme.qml`
   を移植先の QML モジュールに追加する。`Main.qml` はウィンドウ・画面遷移の例なので、移植先に既にある
   ルートに `StackView`（または相当）で `HomeScreen` / `SettingsScreen` を載せればよい。
2. **窓口を用意する**: 移植先の C++ で `clock` / `can` / `androidAuto` に相当するオブジェクトを
   同じプロパティ名で公開する。実データがまだ無い間は `DummyCanModel` のようなダミーで構わない。
3. **映像**: `VideoSurfaceItem.h/.cpp` を移植先にコピーして `qmlRegisterType`（または `QML_ELEMENT`）で登録する。
   映像の入力元は `AndroidAutoController` の 3 つの入口に繋ぐ。
   - `reportState(LinkState, QString)` … 接続状態の通知（どのスレッドからでも可）
   - `pushVideoData(data, size)` … H.264 Annex-B の 1 アクセスユニット（FFmpeg 必須）
   - `pushFrame(QImage)` … デコード済みフレーム
4. 移植先がすでに別の状態管理を持つなら、`AndroidAutoController` を丸ごと使う必要はない。
   QML が見ているプロパティ名（上表）さえ満たせばよい。

## 3. 移植時にハマりやすい点

- **`Theme` が見つからない**: シングルトン登録（`QT_QML_SINGLETON_TYPE`）と `qmldir` の `singleton Theme` が必要。
- **`androidAuto is not defined` などの警告**: コンテキストプロパティを `engine.load()` より前に設定すること。
- **QML 内の文字列は日本語直書き**: C++ 側も QML 側もソースは UTF-8。MSVC は `/utf-8` が必要
  （ルートの `CMakeLists.txt` で指定済み。移植先のビルドにも入れること）。
- **映像の描画**: 現状は `QQuickPaintedItem`（ソフトウェア描画）。実機で重い場合は `QQuickItem` +
  `QSGTexture` への置き換え候補（QML 側の使い方は変わらない）。
- **別スレッドからの更新**: `pushVideoData` / `pushFrame` はスレッドセーフだが、`attachSurface` は GUI スレッドで呼ぶこと。
