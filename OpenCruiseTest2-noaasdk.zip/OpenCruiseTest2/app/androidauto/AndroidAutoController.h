/**
 * @file AndroidAutoController.h
 * @brief Android Auto の接続状態・映像を QML へ橋渡しする Qt 側の窓口。
 *
 * 接続処理そのもの(USB・プロトコル)は持たない。状態と映像は外から reportState() / pushVideoData() /
 * pushFrame() で流し込む設計で、現在の入力元は次の 2 つだけ:
 *   - DemoScenario     : 状態遷移と映像を疑似生成（Windows 等で UI を確認する用。--demo）
 *   - TestVideoFeeder  : H.264 ファイルを流す（デコード経路の確認用。--test-video）
 * 実際の接続層を後から付ける場合も、この 3 つの入口に繋ぐだけでよい。QML 側は変更不要。
 */
#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <mutex>

#include <QObject>
#include <QString>
#include <QTimer>

#include "DemoScenario.h"
#include "H264Decoder.h"
#include "LinkState.h"
#include "TestVideoFeeder.h"

namespace opencruise {

class VideoSurfaceItem;

/**
 * @brief QML 向けの Android Auto 状態モデル兼コントローラ。
 */
class AndroidAutoController : public QObject {
    Q_OBJECT
    /** "unavailable" / "waiting" / "connecting" / "connected" / "streaming"（色分け等に使う） */
    Q_PROPERTY(QString stateKey READ stateKey NOTIFY stateChanged)
    Q_PROPERTY(QString stateText READ stateText NOTIFY stateChanged)
    Q_PROPERTY(QString detailText READ detailText NOTIFY stateChanged)
    /** 状態・映像の入力元の表示名（「なし」「デモ」「テスト映像 (H.264)」） */
    Q_PROPERTY(QString sourceText READ sourceText NOTIFY stateChanged)
    /** 直近の切断理由/エラー。無ければ空 */
    Q_PROPERTY(QString lastIssue READ lastIssue NOTIFY lastIssueChanged)
    Q_PROPERTY(qulonglong frameCount READ frameCount NOTIFY videoStatsChanged)
    Q_PROPERTY(QString videoInfo READ videoInfo NOTIFY videoStatsChanged)
    /** 接続処理を試みた回数（待機に戻るたびに増える） */
    Q_PROPERTY(int attemptCount READ attemptCount NOTIFY stateChanged)
    /** デコード前に受信した映像メッセージ数 */
    Q_PROPERTY(qulonglong videoPacketCount READ videoPacketCount NOTIFY videoStatsChanged)

public:
    /**
     * @brief 状態を「利用不可」で初期化する。入力元はまだ何も始めない。
     * @param parent 親オブジェクト
     */
    explicit AndroidAutoController(QObject *parent = nullptr);

    /** @brief 入力元を停止してから破棄する。 */
    ~AndroidAutoController() override;

    QString stateKey() const { return stateKey_; }
    QString stateText() const { return stateText_; }
    QString detailText() const { return detailText_; }
    QString sourceText() const { return sourceText_; }
    QString lastIssue() const { return lastIssue_; }
    qulonglong frameCount() const { return frameCount_; }
    QString videoInfo() const { return videoInfo_; }
    int attemptCount() const { return attemptCount_; }
    qulonglong videoPacketCount() const { return videoPackets_.load(); }

    /**
     * @brief 映像を描画するアイテムを登録する。QML から呼ぶ。
     * @param surface 描画先
     */
    Q_INVOKABLE void attachSurface(opencruise::VideoSurfaceItem *surface);

    // ---- 入力元から呼ぶ入口（スレッドセーフ） ----

    /**
     * @brief 接続状態を通知する。どのスレッドから呼んでもよい（UI スレッドへキューされる）。
     * @param state 新しい状態
     * @param detail 画面に出す詳細メッセージ
     */
    void reportState(aa::LinkState state, const QString &detail);

    /**
     * @brief H.264 Annex-B の 1 アクセスユニットを渡す。どのスレッドから呼んでもよい。
     */
    void pushVideoData(const std::uint8_t *data, std::size_t size);

    /**
     * @brief デコード済みの 1 フレームを渡す。どのスレッドから呼んでもよい。
     */
    void pushFrame(const QImage &image);

    // ---- 開発用の入力元 ----

    /** @brief UI 確認用デモを開始する（状態が待機→接続→映像受信→切断と巡回し、疑似映像を出す）。 */
    void startDemo();

    /**
     * @brief 開発用: H.264 ファイルを映像として流し込む。FFmpeg が無いビルドでは失敗を状態に出す。
     * @param path H.264 Annex-B ファイル
     */
    void playTestStream(const QString &path);

    /** @brief 入力元（デモ・テスト映像）を停止する。アプリ終了時に呼ばれる。 */
    Q_INVOKABLE void stop();

signals:
    /** @brief 接続状態(stateKey/stateText/detailText/sourceText)が変わったとき。 */
    void stateChanged();
    /** @brief lastIssue が変わったとき。 */
    void lastIssueChanged();
    /** @brief 受信フレーム数または映像サイズ表示が変わったとき。 */
    void videoStatsChanged();

private:
    /** @brief 状態を UI スレッドで反映する。 */
    void applyState(int state, const QString &detail);

    /** @brief デコード済みフレームを描画アイテムへ渡し、統計を更新する（任意のスレッドで呼ばれる）。 */
    void handleDecodedFrame(const QImage &image);

    QString stateKey_;
    QString stateText_;
    QString detailText_;
    QString sourceText_;
    QString lastIssue_;
    QString videoInfo_ = QStringLiteral("-");
    std::atomic<qulonglong> frameCount_{0};
    std::atomic<bool> decoderErrorReported_{false};
    int currentState_ = static_cast<int>(aa::LinkState::Unavailable);

    std::atomic<qulonglong> videoPackets_{0}; ///< デコード前に受信した映像メッセージ数
    std::atomic<qulonglong> videoBytes_{0};   ///< 受信した映像データの累計バイト数
    int attemptCount_ = 0;                    ///< 接続処理を開始/再試行した回数
    qint64 startedAtMs_ = 0;                  ///< 接続処理を開始した実時刻 (エポックミリ秒)
    QTimer watchdog_;                         ///< 進まない状態を記録する定期タイマー

    std::mutex surfaceMutex_;
    VideoSurfaceItem *surface_ = nullptr; ///< surfaceMutex_ で保護

    H264Decoder decoder_;
    TestVideoFeeder testFeeder_;
    DemoScenario demo_;
};

} // namespace opencruise
