/**
 * @file DemoScenario.h
 * @brief 開発用: スマートフォン無し・FFmpeg 無しで UI を確認するための疑似入力元。
 *
 * 状態を「待機 → 接続中 → 接続済み → 映像受信中 → 切断(→待機)」と巡回させ、映像受信中は
 * QPainter で描いた動くテスト画面を QImage として直接渡す（H.264 を経由しない）。
 * 画面の各状態の見た目（色・案内文・切断理由の表示など）を Windows 上で一通り確認できる。
 * すべて GUI スレッドで動作する。
 */
#pragma once

#include <QElapsedTimer>
#include <QImage>
#include <QObject>
#include <QString>
#include <QTimer>

#include "LinkState.h"

namespace opencruise {

/**
 * @brief 時間経過で状態と疑似映像を生成するシナリオ。
 */
class DemoScenario : public QObject {
    Q_OBJECT

public:
    /**
     * @brief 停止状態で作る。
     * @param parent 親オブジェクト
     */
    explicit DemoScenario(QObject *parent = nullptr);

    /** @brief シナリオを最初から開始する。 */
    void start();

    /** @brief シナリオを止める。 */
    void stop();

    /** @brief 実行中か。 */
    bool isRunning() const { return timer_.isActive(); }

signals:
    /** @brief 状態を変えるよう要求する。 */
    void stateRequested(opencruise::aa::LinkState state, const QString &detail);
    /** @brief 映像フレームが 1 枚できた。 */
    void frameReady(const QImage &image);

private:
    /** @brief 一定間隔で呼ばれ、経過時間に応じて状態遷移とフレーム生成を行う。 */
    void tick();

    /** @brief テスト画面（800x480）を 1 枚描く。 */
    QImage renderFrame(qint64 frameIndex) const;

    QTimer timer_;
    QElapsedTimer phaseTimer_;
    int phase_ = -1; ///< -1: 未開始, 0: 待機, 1: 接続中, 2: 接続済み, 3: 映像受信中
    qint64 frameIndex_ = 0;
    int cycle_ = 0; ///< 何周目か（切断理由の表示を変えるため）
};

} // namespace opencruise
