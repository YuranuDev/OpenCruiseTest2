/**
 * @file DemoScenario.cpp
 * @brief DemoScenario の実装。
 */
#include "DemoScenario.h"

#include <cmath>

#include <QColor>
#include <QFont>
#include <QLinearGradient>
#include <QPainter>

namespace opencruise {

namespace {

constexpr int kFrameIntervalMs = 33; ///< 約 30fps
constexpr int kWaitingMs = 3000;
constexpr int kConnectingMs = 2000;
constexpr int kConnectedMs = 1500;
constexpr int kStreamingMs = 12000;

} // namespace

DemoScenario::DemoScenario(QObject *parent) : QObject(parent) {
    timer_.setInterval(kFrameIntervalMs);
    connect(&timer_, &QTimer::timeout, this, &DemoScenario::tick);
}

void DemoScenario::start() {
    phase_ = -1;
    cycle_ = 0;
    frameIndex_ = 0;
    phaseTimer_.start();
    timer_.start();
    tick();
}

void DemoScenario::stop() {
    timer_.stop();
    phase_ = -1;
}

void DemoScenario::tick() {
    const qint64 elapsed = phaseTimer_.elapsed();
    auto enter = [this](int phase, aa::LinkState state, const QString &detail) {
        phase_ = phase;
        phaseTimer_.restart();
        emit stateRequested(state, detail);
    };

    switch (phase_) {
    case -1:
        enter(0, aa::LinkState::Waiting, QStringLiteral("デモ: スマートフォンの接続待ち"));
        break;
    case 0:
        if (elapsed >= kWaitingMs) {
            enter(1, aa::LinkState::Connecting, QStringLiteral("デモ: スマートフォンを検出、ハンドシェイク中"));
        }
        break;
    case 1:
        if (elapsed >= kConnectingMs) {
            enter(2, aa::LinkState::Connected, QStringLiteral("デモ: セッション確立、映像を待っています"));
        }
        break;
    case 2:
        if (elapsed >= kConnectedMs) {
            frameIndex_ = 0;
            enter(3, aa::LinkState::Streaming, QStringLiteral("デモ: 疑似映像を表示中（実際の接続ではありません）"));
        }
        break;
    case 3:
        if (elapsed >= kStreamingMs) {
            ++cycle_;
            // 切断理由の表示確認のため、偶数周と奇数周で文言を変える
            enter(0, aa::LinkState::Waiting,
                  cycle_ % 2 == 1 ? QStringLiteral("デモ: スマートフォンが取り外されました")
                                  : QStringLiteral("デモ: 通信がタイムアウトしました"));
        } else {
            emit frameReady(renderFrame(frameIndex_++));
        }
        break;
    default:
        break;
    }
}

QImage DemoScenario::renderFrame(qint64 frameIndex) const {
    QImage image(800, 480, QImage::Format_RGB32);
    QPainter p(&image);
    p.setRenderHint(QPainter::Antialiasing, true);

    // 背景: ゆっくり色相が回るグラデーション
    const int hue = static_cast<int>((frameIndex * 2) % 360);
    QLinearGradient bg(0, 0, 800, 480);
    bg.setColorAt(0.0, QColor::fromHsv(hue, 120, 90));
    bg.setColorAt(1.0, QColor::fromHsv((hue + 60) % 360, 160, 40));
    p.fillRect(image.rect(), bg);

    // 走る円（動いていることが一目で分かるように）
    const double t = static_cast<double>(frameIndex) / 30.0;
    const int x = static_cast<int>(400 + 300 * std::sin(t * 1.3));
    const int y = static_cast<int>(240 + 140 * std::sin(t * 2.1));
    p.setPen(Qt::NoPen);
    p.setBrush(QColor(255, 255, 255, 200));
    p.drawEllipse(QPoint(x, y), 36, 36);

    // 文字
    p.setPen(Qt::white);
    QFont big;
    big.setPixelSize(56);
    big.setBold(true);
    p.setFont(big);
    p.drawText(QRect(0, 140, 800, 80), Qt::AlignCenter, QStringLiteral("DEMO VIDEO"));
    QFont small;
    small.setPixelSize(26);
    p.setFont(small);
    p.drawText(QRect(0, 220, 800, 40), Qt::AlignCenter,
               QStringLiteral("800 x 480  /  frame %1").arg(frameIndex));
    p.end();
    return image;
}

} // namespace opencruise
