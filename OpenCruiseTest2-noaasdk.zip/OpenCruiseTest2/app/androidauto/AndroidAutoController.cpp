/**
 * @file AndroidAutoController.cpp
 * @brief AndroidAutoController の実装。
 */
#include "AndroidAutoController.h"

#include <QDateTime>
#include <QDebug>
#include <QImage>
#include <QMetaObject>

#include "VideoSurfaceItem.h"

namespace opencruise {

namespace {

/**
 * @brief 状態を QML 用のキー文字列へ変換する。
 */
QString keyFor(aa::LinkState state) {
    switch (state) {
    case aa::LinkState::Unavailable: return QStringLiteral("unavailable");
    case aa::LinkState::Waiting: return QStringLiteral("waiting");
    case aa::LinkState::Connecting: return QStringLiteral("connecting");
    case aa::LinkState::Connected: return QStringLiteral("connected");
    case aa::LinkState::Streaming: return QStringLiteral("streaming");
    }
    return QStringLiteral("unavailable");
}

/**
 * @brief 状態を画面表示用の日本語へ変換する。
 */
QString textFor(aa::LinkState state) {
    switch (state) {
    case aa::LinkState::Unavailable: return QStringLiteral("利用不可");
    case aa::LinkState::Waiting: return QStringLiteral("待機中");
    case aa::LinkState::Connecting: return QStringLiteral("接続中");
    case aa::LinkState::Connected: return QStringLiteral("接続済み");
    case aa::LinkState::Streaming: return QStringLiteral("映像受信中");
    }
    return QString();
}

} // namespace

/**
 * @brief デコーダ・テスト送出・デモを初期化し、状態を「利用不可」にしておく。
 */
AndroidAutoController::AndroidAutoController(QObject *parent)
    : QObject(parent),
      decoder_([this](const QImage &image) { handleDecodedFrame(image); }),
      testFeeder_([this](const std::uint8_t *data, std::size_t size) { pushVideoData(data, size); }),
      demo_(this) {
    stateKey_ = keyFor(aa::LinkState::Unavailable);
    stateText_ = textFor(aa::LinkState::Unavailable);
    detailText_ = QStringLiteral("接続元が組み込まれていません（--demo で UI の動作確認ができます）");
    sourceText_ = QStringLiteral("なし");

    // デモは GUI スレッドで動くので直接つなぐ（reportState / pushFrame はどのスレッドからでも安全）
    connect(&demo_, &DemoScenario::stateRequested, this,
            [this](aa::LinkState state, const QString &detail) { reportState(state, detail); });
    connect(&demo_, &DemoScenario::frameReady, this, [this](const QImage &image) { pushFrame(image); });

    // 接続中/接続済みのまま何も起きない場合に気付けるよう、経過を定期的に記録する。
    connect(&watchdog_, &QTimer::timeout, this, [this]() {
        const auto link = static_cast<aa::LinkState>(currentState_);
        // 接続待ちのままでも「アプリは動いていて状態が変わっていない」ことを記録する
        const qint64 elapsed = startedAtMs_ > 0 ? QDateTime::currentMSecsSinceEpoch() - startedAtMs_ : -1;
        qInfo().noquote() << "[aa] 監視:" << textFor(link) << "のまま" << elapsed << "ms 経過 (受信映像"
                          << videoPackets_.load() << "通 /" << videoBytes_.load() << "バイト, デコード済み"
                          << frameCount_ << "フレーム)";
    });
    watchdog_.start(30000);
}

/**
 * @brief 停止してから破棄する。
 */
AndroidAutoController::~AndroidAutoController() { stop(); }

/**
 * @brief 描画アイテムを登録する。アイテム破棄時に参照を外す。
 */
void AndroidAutoController::attachSurface(VideoSurfaceItem *surface) {
    {
        std::lock_guard<std::mutex> lock(surfaceMutex_);
        surface_ = surface;
    }
    if (surface != nullptr) {
        connect(surface, &QObject::destroyed, this, [this]() {
            std::lock_guard<std::mutex> lock(surfaceMutex_);
            surface_ = nullptr;
        });
    }
}

/**
 * @brief 接続状態を UI スレッドへキューして反映する。
 */
void AndroidAutoController::reportState(aa::LinkState state, const QString &detail) {
    QMetaObject::invokeMethod(
        this, [this, state, detail]() { applyState(static_cast<int>(state), detail); }, Qt::QueuedConnection);
}

/**
 * @brief 映像データをデコーダへ渡す（呼び出したスレッドで実行される）。
 */
void AndroidAutoController::pushVideoData(const std::uint8_t *data, std::size_t size) {
    const qulonglong packets = ++videoPackets_;
    videoBytes_ += static_cast<qulonglong>(size);
    if (packets == 1 || packets % 60 == 0) {
        qInfo().noquote() << "[aa] 映像データを受信しました (累計" << packets << "通 /" << videoBytes_
                          << "バイト, 今回" << size << "バイト)";
    }
    if (!decoder_.isReady()) {
        if (!decoderErrorReported_.exchange(true)) {
            qWarning().noquote() << "[aa] 映像デコーダが使えません:" << decoder_.errorString();
        }
        return;
    }
    decoder_.decode(data, size);
}

/**
 * @brief デコード済みフレームをそのまま表示経路へ流す。
 */
void AndroidAutoController::pushFrame(const QImage &image) { handleDecodedFrame(image); }

/**
 * @brief デモを開始する。
 */
void AndroidAutoController::startDemo() {
    testFeeder_.stop();
    sourceText_ = QStringLiteral("デモ");
    emit stateChanged();
    demo_.start();
}

/**
 * @brief デモとテスト送出を停止する。
 */
void AndroidAutoController::stop() {
    demo_.stop();
    testFeeder_.stop();
}

/**
 * @brief 開発用: テスト映像を流し込み、状態を「映像受信中(テスト)」にする。
 */
void AndroidAutoController::playTestStream(const QString &path) {
    demo_.stop();
    if (!decoder_.isReady()) {
        const QString message = QStringLiteral("映像デコーダが使えません: ") + decoder_.errorString();
        qWarning().noquote() << "[aa] テスト映像を開始できません:" << message;
        sourceText_ = QStringLiteral("テスト映像 (H.264)");
        applyState(static_cast<int>(aa::LinkState::Unavailable), message);
        return;
    }
    QString error;
    if (!testFeeder_.start(path, error)) {
        qWarning().noquote() << "[aa] テスト映像を開始できません:" << error;
        applyState(static_cast<int>(aa::LinkState::Unavailable), error);
        return;
    }
    sourceText_ = QStringLiteral("テスト映像 (H.264)");
    applyState(static_cast<int>(aa::LinkState::Streaming), QStringLiteral("テスト映像を再生中（実接続ではありません）"));
}

/**
 * @brief UI スレッドで状態を更新する。待機/未接続系に戻る時は映像と統計をリセットする。
 */
void AndroidAutoController::applyState(int state, const QString &detail) {
    const auto link = static_cast<aa::LinkState>(state);
    const auto previous = static_cast<aa::LinkState>(currentState_);
    currentState_ = state;

    if (link == aa::LinkState::Connecting && previous != aa::LinkState::Connecting) {
        ++attemptCount_;
        startedAtMs_ = QDateTime::currentMSecsSinceEpoch();
        videoPackets_ = 0;
        videoBytes_ = 0;
        qInfo().noquote() << "[aa] 接続処理を開始します (試行" << attemptCount_ << "回目)";
    } else if (link == aa::LinkState::Waiting && previous != aa::LinkState::Waiting) {
        videoPackets_ = 0;
        videoBytes_ = 0;
        qInfo().noquote() << "[aa] 待機に戻りました (前回:" << textFor(previous) << ")";
    }

    const bool wasActive = previous == aa::LinkState::Connecting || previous == aa::LinkState::Connected ||
                           previous == aa::LinkState::Streaming;
    const bool dropped = (link == aa::LinkState::Waiting && wasActive) || link == aa::LinkState::Unavailable;
    if (dropped && lastIssue_ != detail) {
        lastIssue_ = detail;
        emit lastIssueChanged();
    }

    if (link == aa::LinkState::Waiting || link == aa::LinkState::Connecting || link == aa::LinkState::Unavailable) {
        decoder_.reset();
        decoderErrorReported_ = false;
        frameCount_ = 0;
        videoInfo_ = QStringLiteral("-");
        emit videoStatsChanged();
        std::lock_guard<std::mutex> lock(surfaceMutex_);
        if (surface_ != nullptr) {
            surface_->clear();
        }
    }

    stateKey_ = keyFor(link);
    stateText_ = textFor(link);
    detailText_ = detail;
    qInfo().noquote() << "[aa] 状態:" << stateText_ << "-" << detail
                      << (startedAtMs_ > 0 ? QStringLiteral("(接続開始から %1 ms)")
                                                 .arg(QDateTime::currentMSecsSinceEpoch() - startedAtMs_)
                                           : QString());
    emit stateChanged();
}

/**
 * @brief デコード済みフレームを描画アイテムへ渡す。統計表示は 30 フレームごと(と初回)に更新する。
 */
void AndroidAutoController::handleDecodedFrame(const QImage &image) {
    {
        std::lock_guard<std::mutex> lock(surfaceMutex_);
        if (surface_ != nullptr) {
            surface_->submitFrame(image);
        }
    }
    const qulonglong count = ++frameCount_;
    if (count == 1 || count % 30 == 0) {
        qInfo().noquote() << "[aa] デコード済みフレーム:" << count << "枚目" << image.width() << "x"
                          << image.height();
        const QString info = QStringLiteral("%1 x %2").arg(image.width()).arg(image.height());
        QMetaObject::invokeMethod(
            this,
            [this, info]() {
                videoInfo_ = info;
                emit videoStatsChanged();
            },
            Qt::QueuedConnection);
    }
}

} // namespace opencruise
