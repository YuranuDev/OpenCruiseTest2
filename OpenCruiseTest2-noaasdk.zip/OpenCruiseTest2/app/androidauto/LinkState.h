/**
 * @file LinkState.h
 * @brief Android Auto 接続状態の定義（Qt にも特定の接続ライブラリにも依存しない）。
 *
 * 接続を担う層（デモ・テスト映像・将来の実接続）と AndroidAutoController の間で共有する型。
 */
#pragma once

namespace opencruise::aa {

/**
 * @brief Android Auto との接続状態。
 */
enum class LinkState {
    Unavailable, ///< 接続元が無い／使えない（接続層が組み込まれていない、初期化失敗など）
    Waiting,     ///< スマートフォンの接続待ち（待機状態）
    Connecting,  ///< スマートフォンを検出し、ハンドシェイク/サービス探索中
    Connected,   ///< 制御チャネルの確立完了。映像はまだ来ていない
    Streaming    ///< 映像データを受信中
};

} // namespace opencruise::aa
