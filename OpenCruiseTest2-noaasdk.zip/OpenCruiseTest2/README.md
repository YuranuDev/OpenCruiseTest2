# OpenCruise — Qt Quick 車載システム UI プロトタイプ

x86_64 PC（Windows / Linux）向けの車載システム UI 試作。Qt Quick(QML) + C++ + CMake。
**完成品ではなく、UI を Windows で作って確認し、実際の QML 側へ移すための土台**。

Android Auto の接続処理 (aasdk) は取り除いてある。接続状態と映像は `AndroidAutoController` が受け取る形になっており、
現在の入力元は開発用の「デモ」と「H.264 テスト映像」だけ。

## 構成

```
OpenCruise/
├── CMakeLists.txt
├── docs/QML_INTEGRATION.md   QML を別プロジェクトへ移す時の契約（必読）
├── scripts/make_test_stream.sh   開発用テスト映像(H.264)の生成
└── app/
    ├── main.cpp              起動・モデル生成・QML 公開・開発用オプション
    ├── core/                 ClockModel(時計) / DummyCanModel(ダミーCAN) / Log(ログ基盤)
    ├── androidauto/
    │   ├── AndroidAutoController.*  状態・映像を QML に橋渡し。入力元は reportState/pushVideoData/pushFrame で渡す
    │   ├── DemoScenario.*           疑似の状態遷移＋疑似映像（--demo。FFmpeg 不要）
    │   ├── H264Decoder.*            FFmpeg による H.264 デコード（FFmpeg が無ければスタブ）
    │   ├── TestVideoFeeder.*        H.264 ファイルを流す（--test-video）
    │   ├── VideoSurfaceItem.*       映像を描く QML アイテム
    │   └── LinkState.h              接続状態の enum
    └── qml/                  Main / HomeScreen / SettingsScreen / CanPanel / ConnectionBadge / ActionButton / Theme
```

## ビルド

### Windows（UI 確認用。FFmpeg 不要）

必要なもの: Qt 6.4 以降（Qt Quick / Qt Quick Controls 2 を含む）、CMake 3.21 以降、MSVC または MinGW。

```bat
:: Qt のパスは環境に合わせる（例: Qt 6.6.x の MSVC 2019 64bit）
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=C:\Qt\6.6.3\msvc2019_64
cmake --build build
:: DLL を集める（初回のみ）
C:\Qt\6.6.3\msvc2019_64\bin\windeployqt.exe --qmldir app\qml build\app\opencruise.exe
build\app\opencruise.exe --demo
```

Qt Creator で開く場合は、ルートの `CMakeLists.txt` を開き、実行時の引数に `--demo` を設定する。
FFmpeg が見つからなくても自動で無効になり、そのままビルドできる（`--test-video` だけが使えなくなる）。

### Ubuntu 24.04

```bash
sudo apt install build-essential cmake ninja-build pkg-config \
  qt6-base-dev qt6-declarative-dev qml6-module-qtquick qml6-module-qtquick-controls \
  qml6-module-qtquick-layouts qml6-module-qtquick-window qml6-module-qtquick-templates \
  qml6-module-qtqml qml6-module-qtqml-workerscript fonts-noto-cjk
# H.264 テスト映像も使う場合のみ
sudo apt install libavcodec-dev libavutil-dev libswscale-dev

cmake -G Ninja -S . -B build -DCMAKE_BUILD_TYPE=Release
ninja -C build
./build/app/opencruise --demo
```

- FFmpeg を明示的に切る: `-DOPENCRUISE_ENABLE_FFMPEG=OFF`
- MSVC では `/utf-8` を付けている（日本語の文字列リテラルが文字化けしないようにするため）

### 開発用オプション

| オプション | 内容 |
|---|---|
| `--demo` | 状態（待機→接続中→接続済み→映像受信中→切断）を巡回し、疑似映像を表示。UI の各状態の確認用 |
| `--test-video <file>` | H.264 ファイルを映像として表示（要 FFmpeg）。`scripts/make_test_stream.sh` で生成 |
| `--screenshot <png> [--screenshot-delay <ms>]` | 画面を保存して終了 |
| `--open-settings` | 設定画面を開いた状態で起動 |
| `--fullscreen` | 全画面 |
| `--log-dir <path>` / `--log-level <level>` | ログの保存先 / 最小レベル |

オプション無しで起動すると、状態は「利用不可」のまま（入力元が無いだけで UI は動く）。

ヘッドレス確認例: `QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software ./build/app/opencruise --demo --screenshot out.png --screenshot-delay 9000`
（デモは約 6.5 秒で映像受信中に入り、そこから約 12 秒間映像を出す）

## 実装状況

| 機能 | 状態 | 検証 |
|---|---|---|
| Qt Quick メイン画面（時計、接続状態、映像領域、CANパネル、設定ボタン） | 実装 | Linux(offscreen)でビルド・起動・画面保存を確認 |
| 設定画面への遷移（StackView） | 実装 | 描画を確認。ボタンのタップ操作は未確認 |
| 接続状態の表示（利用不可/待機中/接続中/接続済み/映像受信中、切断理由の保持） | 実装 | `--demo` で映像受信中の画面と設定画面を確認 |
| 疑似映像の表示（QImage → VideoSurfaceItem） | 実装 | `--demo` で確認 |
| H.264 デコード → 表示 | 実装（FFmpeg 有効時） | Linux(offscreen)で `--test-video` の 800x480 表示を確認 |
| Windows でのビルド | CMake を対応 | **未検証**（この環境は Linux のため。MSVC/MinGW での確認が必要） |

### 未実装

- 実際の Android Auto 接続（aasdk は除去済み）
- 実 CAN 通信（ダミーのみ）
- 設定の保存、画面の多言語化（UI 文字列は日本語直書き）
- GPU 描画（現状は `QQuickPaintedItem` のソフトウェア描画）

## 実際の QML へ移す

`docs/QML_INTEGRATION.md` を参照。
